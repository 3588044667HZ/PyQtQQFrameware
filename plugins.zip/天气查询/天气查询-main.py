import tkinter

name = '天气查询'
import requests

from sdk import Bot

key1 = 'SO-owjXNal9_usfNs'  # 心知天气私钥
rev = {}
gp_id = 0
qqbot = None
complain = '查询天气'


def init(p_id: int, Api: object):  # 插件第一次安装时调用
    global gp_id
    global qqbot
    gp_id = p_id
    qqbot = Bot(Api=Api,p_id=p_id)
    return {'name': name, 'complain': complain, 'author': 'None', 'ver': '0.1', 'p_id': p_id}


def enable(Api: object, p_id: int):  # 插件被启用时被调用
    global qqbot
    qqbot = Bot(Api, p_id=p_id)
    return {'name': name, 'complain': complain, 'author': 'None', 'ver': '0.1', 'p_id': p_id}


qq = list()


def on_private_msg(dic):
    global qq
    if dic['message'] == '天气查询':
        global rev
        rev = dic
        qqbot.send_msg({'msg_type': 'private', 'number': dic['user_id'], 'msg': '请发送一个城市'})
        qq.append(dic['user_id'])
    elif dic['user_id'] in qq:
        qq.remove(dic['user_id'])
        url = 'https://api.seniverse.com/v3/weather/now.json?key={0}&location={1}&language=zh-Hans&unit=c'.format(
            key1,
            dic['message'])
        res = requests.get(url).json()
        fin = res['results'][0]['location']["path"] + '\n' + res['results'][0]['now']['text'] + '\n' + \
              res['results'][0]['now']['temperature'] + '摄氏度'
        qqbot.send_msg({'msg_type': 'private', 'number': dic['user_id'], 'msg': fin})


def on_group_msg(dic):
    if dic['message'] == '天气查询':
        global rev
        rev = dic
        qqbot.send_group_msg(dic['group_id'], '请发送城市')
        global qq
        qq.append(dic['user_id'])
    elif dic['user_id'] in qq:
        qq.remove(dic['user_id'])
        url = 'https://api.seniverse.com/v3/weather/now.json?key={0}&location={1}&language=zh-Hans&unit=c'.format(
            key1,
            dic['message'])
        res = requests.get(url).json()
        # print(res)
        fin = res['results'][0]['location']["path"] + '\n' + res['results'][0]['now']['text'] + '\n' + \
              res['results'][0]['now']['temperature'] + '摄氏度'
        qqbot.send_group_msg(dic['group_id'], fin)


def on_notice(dic):
    pass


def setting():
    tk = tkinter.Tk()
    tk.geometry('300x200')
    tk.title('天气查询')
    tkinter.Label(tk, text='test').pack()
    e = tkinter.Entry(tk)
    e.pack()
    b = tkinter.Button(text='确定')
    b.pack()
    tk.mainloop()
