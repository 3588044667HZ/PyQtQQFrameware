import tkinter

name = 'p1'
import json

import requests

from sdk import Bot

url = 'https://api.mlyai.com/reply'
mly_head = {'Api-Key': '2ua9pfvnol0wgxu6', 'Api-Secret': 'fgnfnihw', 'Content-Type': 'application/json;charset=UTF-8'}
qqbot = None
# gp_id = 0


def init(Api: object, p_id: int):  # 框架启动调用
    # global gp_id
    global qqbot
    # gp_id = p_id
    qqbot = Api
    return {'name': name, 'complain': '茉莉云AI对话', 'author': 'huazi', 'ver': '0.1', 'p_id': p_id}


def close():
    pass


def enable(Api: object, p_id: int):  # 插件被启用时被调用
    global qqbot
    # qqbot = Bot(Api, p_id=p_id)
    qqbot=Api
    return {'name': name, 'complain': '茉莉云对话AI', 'author': 'None', 'ver': '0.1', 'p_id': p_id}


def disable():
    pass


def on_group_msg(dic: dict):
    try:
        msg = dic['message']
        qq = dic['user_id']
        if dic['post_type'] == 'message' and '[CQ:at,qq=3155789073]' in dic['message']:
            data = {'content': msg.replace('[CQ:at,qq=3155789073]', ''), 'type': '2', 'from': qq,
                    'fromName': dic['sender']['nickname'], 'to': dic['group_id']}
            res = requests.post(url, data=json.dumps(data), headers=mly_head).json()
            qqbot.send_group_msg(dic['group_id'], res['data'][0]['content'])
    except:
        pass


def on_private_msg(dic: dict):
    try:
        msg = dic['message']
        qq = dic['user_id']
        if dic['message'] == '一言':
            return
        elif dic['message'] == '一图':
            return
        elif '搜图' in dic['message'] and dic['message'].index('搜图') == 0:
            return
        elif dic["message"] == '老黄历':
            return
        elif dic['message'] == '百度词条':
            return
        elif dic['message'] == '查询天气':
            return
        elif dic['message'] == '华子我要个性名片':
            return
        elif '禁言' in dic['message'] and dic['message'].index('禁言') == 0:
            return
        elif '解除禁言' in dic['message'] and dic['message'].index('解除禁言') == 0:
            return
        elif '加代管' in dic['message'] and dic['message'].index('加代管') == 0:
            return
        elif '删代管' in dic['message'] and dic['message'].index('删代管') == 0:
            return
        elif dic['message'] == '查询所有代管':
            return
        elif '我要头衔' in dic['message'] and dic['message'].index('我要头衔') == 0:
            return
        elif '固定头衔' in dic['message'] and dic['message'].index('固定头衔') == 0:
            return
        elif '解除固定' in dic['message'] and dic['message'].index('解除固定') == 0:
            return
        elif '设置头衔' in dic['message'] and dic['message'].index('设置头衔') == 0:
            return
        elif dic['message'] == '每日新闻':
            return
        if ('sender_id' in dic and 'group_id' not in dic) or dic['message_type'] == 'private':
            data = {'content': msg, 'type': '1', 'from': qq}
            res = requests.post(url, data=json.dumps(data), headers=mly_head).json()
            qqbot.send_msg({'msg_type': 'private', 'number': dic['user_id'], 'msg': res['data'][0]['content']})
    except:
        pass


def on_notice(dic):
    msg: str = dic['sub_type']
    qq = dic['sender_id']
    if dic['post_type'] == 'notice':
        data = {'content': msg, 'type': '2', 'from': qq,
                'fromName': dic['sender']['nickname'], 'to': dic['group_id']}
        res = requests.post(url, data=json.dumps(data), headers=mly_head).json()
        qqbot.send_group_msg(dic['group_id'], res['data'][0]['content'])


def setting():
    tk = tkinter.Tk()
    tk.geometry('300x200')
    tk.title('p1')
    tkinter.Label(tk, text='输入主人').pack()
    e = tkinter.Entry(tk)
    e.pack(fill=tkinter.X)
    b = tkinter.Button(text='确定')
    b.pack()
    tk.mainloop()


if __name__ == '__main__':
    setting()
