name = '随机诗句'

import requests

from sdk import Bot

qqbot = None
api = 'https://v1.jinrishici.com/all.json'
g_pid = 0


def enable(Api: object, p_id: int):  # 插件被启用时被调用
    global qqbot
    qqbot = Bot(Api,p_id=p_id)
    return {'name': name, 'complain': '关键词：一言', 'author': 'None', 'ver': '0.1', 'p_id': p_id}


def init(p_id: int, Api: object):  # 插件第一次安装时调用
    global gp_id
    global qqbot
    gp_id = p_id
    qqbot = Bot(Api, p_id)
    return {'name': name, 'complain': '关键词：一言', 'author': 'huazi', 'ver': '0.1', 'p_id': p_id}


def close():
    pass


def on_group_msg(dic: dict):
    if dic['message'] == '一言':
        response = requests.post(api).json()
        r1 = response['content'] + '\n' + '出处：' + response['origin'] + '\n' + '作者：' + response[
            'author'] + '\n' + '标签:' + response['category']
        qqbot.send_msg({'msg_type': 'group', 'number': dic['group_id'], 'msg': r1})


def on_private_msg(dic: dict):
    if dic['message'] == '一言':
        response = requests.post(api).json()
        r1 = response['content'] + '\n' + '出处：' + response['origin'] + '\n' + '作者：' + response[
            'author'] + '\n' + '标签:' + response['category']
        # print(r1)
        qqbot.send_msg({'msg_type': 'private', 'number': dic['user_id'], 'msg': r1})


def on_notice(dic):
    pass
def setting():
    pass