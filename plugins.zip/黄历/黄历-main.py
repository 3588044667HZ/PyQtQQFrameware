name = '黄历'
import requests

from sdk import Bot

api = 'http://xiaobai.klizi.cn/API/other/laohuangli.php'

gp_id = 0
complain = '老黄历'
qqbot = None


def init(p_id: int, Api: object):  # 插件第一次安装时调用
    global gp_id
    global qqbot
    gp_id = p_id
    qqbot = Bot(Api, p_id)
    return {'name': name, 'complain': complain, 'author': 'None', 'ver': '0.1', 'p_id': p_id}


def enable(Api: object, p_id: int):  # 插件被启用时被调用
    global gp_id
    global qqbot
    gp_id = p_id
    qqbot = Bot(Api, p_id)
    return {'name': name, 'complain': complain, 'author': 'None', 'ver': '0.1', 'p_id': p_id}


def disable():  # 插件被禁用时被调用
    pass


def on_private_msg(dic):
    if dic['message'] == '老黄历':
        s = requests.get(api).text
        qqbot.send_msg({'msg_type': 'private', 'number': dic['user_id'], 'msg': s})


def on_group_msg(dic):
    if dic['message'] == '老黄历':
        s = requests.get(api).text
        qqbot.send_group_msg(dic['group_id'], s)


def on_notice(dic):
    pass


def setting():
    pass
